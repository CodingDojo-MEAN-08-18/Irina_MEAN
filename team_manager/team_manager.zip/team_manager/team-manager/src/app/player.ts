export class Player {
    _id: string;
    name: string;
    prefPosition: string;
    game1: number;
    game2: number;
    game3: number;
    createdAt: Date;
    updatedAt: Date;
}
